class Lege extends Ansatt{
    final String ansattidentifikajson;
    final String navn;
    int legeNummer;
}
