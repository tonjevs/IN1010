class Adminlege extends Overlege implements Administrator{
    final String ansattidentifikajson;
    final String navn;
    int legeNummer;
    String spesialiseringstype;
    String ansvarsKode;
}
