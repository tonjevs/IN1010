public interface Administrator{
    String ansvarsKode;
}