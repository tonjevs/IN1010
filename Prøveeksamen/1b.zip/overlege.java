class Overlege extends Lege{
    final String ansattidentifikajson;
    final String navn;
    int legeNummer;
    String spesialiseringstype;
    
}
