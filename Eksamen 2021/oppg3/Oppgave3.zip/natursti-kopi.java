class Natursti extends Sti{

    Natursti(int lengde, Kryss kryssStart, Kryss kryssSlutt)  {
        super(lengde, kryssStart, kryssSlutt);
    }
    
}
