class Kjerrevei extends Sti{

    Kjerrevei(int lengde, Kryss kryssStart, Kryss kryssSlutt) {
        super(lengde, kryssStart,kryssSlutt);
    }
    
}
