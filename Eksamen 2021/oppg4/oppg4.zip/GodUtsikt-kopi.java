interface GodUtsikt{
}
