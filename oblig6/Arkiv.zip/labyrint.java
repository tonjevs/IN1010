import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

class Labyrint{
    String filnavn;
    Ruter[][] rutenett;
    ArrayList<ArrayList<Tuppel>> hele;
    int rader;
    int kolonner;

    public Labyrint(File filnavn)throws FileNotFoundException{

        int koord1 = 0;
        int koord2 = 0;
        hele = new ArrayList<>();

        try{
            Scanner in = new Scanner(filnavn);

            String linje = in.nextLine();
            String[] tallListe = linje.split(" ");
            rader = Integer.parseInt(tallListe[0]);
            kolonner = Integer.parseInt(tallListe[1]);
            
            rutenett = new Ruter[rader][kolonner];
            
            while(in.hasNextLine()){

                String linjene = in.nextLine();
                String[] linjer = linjene.split("");
                for (String symbol : linjer){
                    
                    if(symbol.equals("#")){
                        rutenett[koord1][koord2] = new Sortrute(koord1,koord2++,this,rutenett);
                    }

                    else if(symbol.equals(".")){
                        if(koord1 == 0 || koord2 == 0 || koord1 == rader - 1 || koord2 == kolonner - 1){
                            rutenett[koord1][koord2] = new Aapning(koord1,koord2++,this,rutenett);
                        }
                        else{
                            rutenett[koord1][koord2] = new Hvitrute(koord1,koord2++,this,rutenett);
                        }
                    }
                }

                System.out.println("");
                koord1++;
                koord2 = 0;
            }
            for(int i = 0; i < rader; i++){
                for(int j = 0; j < kolonner;j++){
                    rutenett[i][j].settNabo();
                }
            }            

        }catch(FileNotFoundException e){
            throw new FileNotFoundException();
        }
    }
    
    public ArrayList<ArrayList<Tuppel>> finnUtveiFra(int kol, int rad){
        rutenett[rad][kol].finnUtvei();
        return hele;
    }

    @Override
    public String toString(){
        String ruter = "";
        for (int i = 0; i < rader; i++) {
            for (int k = 0; k < kolonner; k++){
                ruter += rutenett[i][k].chartilTegn();
            }
            ruter = ruter + "\n";
        }
        return ruter;
    }
}
